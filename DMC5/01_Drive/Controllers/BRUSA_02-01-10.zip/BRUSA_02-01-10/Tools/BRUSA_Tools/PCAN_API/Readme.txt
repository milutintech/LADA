
Die Exe PCAN_API beinhaltet die USB Treiber und die canapi2.dll f�r 32-bit und
64-bit Systeme. Das Paket ist f�r BRUSA Lizenziert und beinhaltet auch unsere
Lizenznummer. Dieses Paket darf zusammen den unseren Tools verwendet werden. 

The Exe PCAN_API contains the USB drivers and canapi2.dll for 32-bit and
64-bit systems. The package is licensed for BRUSA and also includes our
license number. This package can be used together with our tools .
